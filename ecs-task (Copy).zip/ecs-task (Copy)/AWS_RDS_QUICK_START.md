# AWS RDS Quick Setup

## Configuration Files Updated ✅

- **docker-compose.yml** - Removed local MySQL service, now connects only to AWS RDS
- **.env** - Template for AWS RDS configuration  
- **backend/.env.example** - AWS RDS connection template
- **AWS_RDS_SETUP.md** - Complete AWS RDS setup guide

## Quick Setup Steps

### 1. Update .env File

Edit `/home/fl-lpt-436/ecs-task/.env` with your AWS RDS details:

```env
MYSQL_HOST=your-rds-endpoint.region.rds.amazonaws.com
MYSQL_USER=admin
MYSQL_PASSWORD=your_password_from_rds
MYSQL_DB=registration_db
MYSQL_PORT=3306
```

### 2. Find Your RDS Endpoint

AWS Console → RDS → Databases → Your Instance → Connectivity & security → Endpoint

Example: `mydb.c9akciq32.us-east-1.rds.amazonaws.com`

### 3. Create Database & Tables

```bash
# Option 1: From command line
mysql -h your-endpoint -u admin -p < backend/database.sql

# Option 2: AWS Console - Run query directly
```

### 4. Configure Security Group

AWS Console → RDS → DB Instance → Connectivity & security → Security group:
- Add inbound rule for port 3306
- Source: 0.0.0.0/0 (or restrict to your IP)

### 5. Start Application

```bash
cd /home/fl-lpt-436/ecs-task
docker-compose down -v
docker-compose up -d
docker-compose ps
```

### 6. Verify Connection

```bash
# Check backend logs
docker-compose logs -f backend

# Test API
curl http://localhost:5000/api/users

# Open frontend
http://localhost:3000
```

## Current Configuration

✅ **Frontend**: React on port 3000 (unchanged)
✅ **Backend**: Flask on port 5000, connects to AWS RDS
✅ **Database**: AWS RDS MySQL (not Docker container)
✅ **Docker**: Backend and Frontend only

## No Local MySQL Container

The local MySQL Docker container has been **removed** from docker-compose.yml 

Your application now connects directly to your AWS RDS instance.

## Support

Detailed guide: See `AWS_RDS_SETUP.md`
General guide: See `README.md`
Docker guide: See `DOCKER_SETUP.md`
