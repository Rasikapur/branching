# Docker Setup Guide

Complete guide to running the Registration Application using Docker and Docker Compose.

## Table of Contents
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Detailed Setup](#detailed-setup)
- [Usage](#usage)
- [Troubleshooting](#troubleshooting)

## Prerequisites

### Required
- **Docker** (v20.10 or higher) - [Install Docker](https://docs.docker.com/get-docker/)
- **Docker Compose** (v1.29 or higher) - [Install Docker Compose](https://docs.docker.com/compose/install/)

### Verify Installation
```bash
docker --version
docker-compose --version
```

## Quick Start

### Option 1: Using Shell Script (Recommended for Linux/macOS)

```bash
# Make script executable
chmod +x start.sh

# Run the script
./start.sh
```

### Option 2: Manual Docker Compose

```bash
# Copy environment file
cp .env.example .env

# Start all services
docker-compose up -d

# Wait for services to initialize (about 10-15 seconds)
```

Then open **http://localhost:3000** in your browser.

## Detailed Setup

### Step 1: Environment Configuration

```bash
# Copy the example environment file
cp .env.example .env
```

Edit the `.env` file with your desired configuration:

```env
# MySQL Configuration
MYSQL_HOST=mysql
MYSQL_USER=registration_user
MYSQL_PASSWORD=user_password
MYSQL_ROOT_PASSWORD=root_password
MYSQL_DB=registration_db
MYSQL_PORT=3306

# Flask Backend
FLASK_ENV=development
FLASK_DEBUG=False

# React Frontend
REACT_APP_API_URL=http://localhost:5000
REACT_APP_API_TIMEOUT=10000
```

### Step 2: Build and Run Containers

```bash
# Build images and start containers
docker-compose up -d

# Monitor the startup process
docker-compose logs -f
```

The `-d` flag runs containers in detached mode (background).

### Step 3: Verify Services

```bash
# Check running containers
docker-compose ps
```

Expected output:
```
NAME                    STATUS
registration_mysql      Up (healthy)
registration_backend    Up
registration_frontend   Up
```

### Step 4: Access the Application

- **Frontend UI**: http://localhost:3000
- **Backend API**: http://localhost:5000
- **MySQL Database**: localhost:3306

## Usage

### Common Docker Compose Commands

#### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f frontend
docker-compose logs -f backend
docker-compose logs -f mysql

# Last N lines
docker-compose logs --tail=50 backend
```

#### Manage Services
```bash
# Stop all services (preserve volumes)
docker-compose stop

# Start stopped services
docker-compose start

# Restart services
docker-compose restart

# Stop and remove all (preserve volumes)
docker-compose down

# Stop and remove everything (delete volumes)
docker-compose down -v

# Rebuild images
docker-compose up -d --build

# Rebuild specific service
docker-compose build frontend
docker-compose up -d frontend
```

#### Access Container Shells

```bash
# Access backend container
docker exec -it registration_backend bash

# Access frontend container
docker exec -it registration_frontend sh

# Access MySQL container
docker exec -it registration_mysql mysql -u registration_user -p registration_db
# Password: user_password
```

#### Run Commands in Containers

```bash
# List files in backend
docker exec registration_backend ls -la

# Check Python version
docker exec registration_backend python --version

# Run npm commands in frontend
docker exec registration_frontend npm --version
```

### Database Management

#### Connect to MySQL

```bash
docker exec -it registration_mysql mysql -u registration_user -p registration_db
# Password: user_password
```

#### View Database Tables

```bash
docker exec registration_mysql mysql -u registration_user -puser_password -D registration_db -e "SHOW TABLES;"
```

#### Backup Database

```bash
docker exec registration_mysql mysqldump \
  -u registration_user \
  -puser_password \
  registration_db > backup.sql
```

#### Restore Database

```bash
docker exec -i registration_mysql mysql \
  -u registration_user \
  -puser_password \
  registration_db < backup.sql
```

## Testing the Application

### 1. Register a New User

1. Open http://localhost:3000
2. Fill in the registration form:
   - First Name: John
   - Last Name: Doe
   - Email: john@example.com
   - Phone: 1234567890
   - Password: password123
3. Click "Register"

### 2. View Registered Users

1. Click "Show Registered Users" button
2. You should see a table with all registered users

### 3. Test Backend API

```bash
# Register user via API
curl -X POST http://localhost:5000/api/register \
  -H "Content-Type: application/json" \
  -d '{
    "first_name": "Jane",
    "last_name": "Doe",
    "email": "jane@example.com",
    "phone": "9876543210",
    "password": "password123"
  }'

# Get all users
curl http://localhost:5000/api/users

# Get specific user
curl http://localhost:5000/api/users/1
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Docker Network                               │
│          (registration_network - bridge driver)                │
│                                                                 │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────┐  │
│  │   Frontend       │  │   Backend        │  │   MySQL      │  │
│  │  (React - Node)  │  │ (Flask - Python) │  │  (Database)  │  │
│  │  Port 3000       │  │  Port 5000       │  │  Port 3306   │  │
│  │                  │  │                  │  │              │  │
│  │  http://         │  │  http://         │  │  Hostname:   │  │
│  │  localhost:3000  │  │  localhost:5000  │  │  mysql       │  │
│  └────────┬─────────┘  └────────┬─────────┘  └──────────────┘  │
│           │                     │                               │
│           └─────────────────────┼───────────────────────────────┤
│                                 │                               │
│                            Internal Network                     │
└─────────────────────────────────┼──────────────────────────────┘
                                  │
                            ┌─────▼─────┐
                            │   Host    │
                            │ localhost │
                            └───────────┘
```

## Volume Management

The application uses Docker volumes to persist data:

### Volumes
- `mysql_data`: Stores MySQL database files

### View Volumes
```bash
docker volume ls
docker volume inspect ecs-task_mysql_data
```

### Clean Volumes
```bash
# Remove all unused volumes
docker volume prune

# Remove specific volume
docker volume rm ecs-task_mysql_data
```

## Troubleshooting

### Services Won't Start

```bash
# Check Docker daemon
docker ps

# Check compose syntax
docker-compose config

# View detailed logs
docker-compose logs

# Restart Docker daemon (Linux)
sudo systemctl restart docker
```

### Port Already in Use

```bash
# Check what's using port 3000
lsof -i :3000

# Change port in docker-compose.yml
# ports:
#   - "3001:3000"  # Use 3001 instead of 3000
```

### Database Connection Issues

```bash
# Check if MySQL is running
docker-compose ps mysql

# Test connection
docker exec registration_backend python -c "
import MySQLdb
try:
    conn = MySQLdb.connect(host='mysql', user='registration_user', passwd='user_password', db='registration_db')
    print('✅ Database connection successful')
    conn.close()
except Exception as e:
    print(f'❌ Database connection failed: {e}')
"
```

### Frontend Can't Connect to Backend

```bash
# Check backend is running
docker-compose ps backend

# Test backend from frontend container
docker exec registration_frontend curl http://backend:5000/

# Check logs
docker-compose logs backend
```

### MySQL Initialization Failed

```bash
# Check MySQL logs
docker-compose logs mysql

# Verify database.sql exists
ls -la backend/database.sql

# Recreate container
docker-compose down -v
docker-compose up -d
```

### Clean Slate

If everything goes wrong, start fresh:

```bash
# Stop all containers
docker-compose down -v

# Remove images
docker-compose rm -f

# Rebuild from scratch
docker-compose up -d --build

# View logs
docker-compose logs -f
```

## Performance Tips

1. **Resource Limits** - Set limits in docker-compose.yml:
```yaml
services:
  mysql:
    deploy:
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
```

2. **Build Cache** - Clean build cache if having issues:
```bash
docker-compose build --no-cache
```

3. **Optimize Images** - Multi-stage builds are used for frontend to reduce size

4. **Mount Volumes** - Use bind mounts for development:
```bash
# In docker-compose.yml
volumes:
  - ./backend:/app
```

## Security Notes

### For Production

1. **Change Passwords** - Update all default passwords in `.env`
2. **Use Secrets** - Don't commit `.env` file, use Docker Secrets
3. **Network Isolation** - Use external networks
4. **SSL/TLS** - Add reverse proxy (nginx) with SSL
5. **Database** - Don't expose port 3306 to public
6. **Disable Debug** - Set `FLASK_DEBUG=False`

### Example Production .env
```env
MYSQL_ROOT_PASSWORD=secure_root_password_here
MYSQL_PASSWORD=secure_user_password_here
FLASK_ENV=production
FLASK_DEBUG=False
```

## Additional Resources

- [Docker Documentation](https://docs.docker.com/)
- [Docker Compose Reference](https://docs.docker.com/compose/compose-file/)
- [Best Practices for Writing Dockerfiles](https://docs.docker.com/develop/dev-best-practices/)
- [Flask with Docker](https://flask.palletsprojects.com/en/2.3.x/deploying/docker/)
- [React Docker Setup](https://create-react-app.dev/docs/deployment/#docker)

## Support

For issues or questions:
1. Check the logs: `docker-compose logs -f`
2. Review this guide's Troubleshooting section
3. Check individual service documentation
4. Open an issue on GitHub

---

Happy containerizing! 🐳
