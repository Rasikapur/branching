import React from 'react';
import './App.css';
import RegistrationForm from './components/RegistrationForm';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>User Registration Form</h1>
      </header>
      <RegistrationForm />
    </div>
  );
}

export default App;
