#!/bin/bash

# Stop and remove all containers and volumes

set -e

echo "=================================="
echo "Stopping and Removing Containers"
echo "=================================="
echo ""

if command -v docker-compose &> /dev/null; then
    echo "🛑 Stopping Docker Compose services..."
    docker-compose down -v
    echo "✅ All containers and volumes removed"
else
    echo "❌ Docker Compose is not installed"
    exit 1
fi

echo ""
echo "✅ Cleanup complete!"
echo ""
