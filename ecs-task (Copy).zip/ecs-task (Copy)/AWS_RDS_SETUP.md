# AWS RDS MySQL Setup Guide

Complete guide to connecting the Registration Application to AWS RDS MySQL.

## Table of Contents
- [Prerequisites](#prerequisites)
- [Create AWS RDS Instance](#create-aws-rds-instance)
- [Configure Security Groups](#configure-security-groups)
- [Create Database and Tables](#create-database-and-tables)
- [Configure Application](#configure-application)
- [Run with Docker](#run-with-docker)
- [Troubleshooting](#troubleshooting)

## Prerequisites

- AWS Account with appropriate permissions
- Docker and Docker Compose installed
- MySQL client tool (optional, for testing)

## Create AWS RDS Instance

### Step 1: Create RDS Instance

1. Go to [AWS RDS Console](https://console.aws.amazon.com/rds/)
2. Click **Create Database**
3. Select **MySQL** engine
4. Choose **Free Tier** or your desired instance class
5. Set **DB instance identifier**: `registration-db`
6. Set **Master username**: `admin`
7. Set **Master password**: (Use a strong password)
8. Note down these credentials

### Step 2: Configure Storage

- **Allocated storage**: 20 GB (or more)
- **Storage type**: General Purpose (SSD)
- **Enable storage autoscaling**: Yes

### Step 3: Configure Connectivity

- **Publicly accessible**: Yes (if accessing from outside VPC)
- **VPC**: Default or your preferred VPC
- **DB subnet group**: Default
- **Public accessibility**: Yes
- **Port**: 3306 (default)

### Step 4: Additional Configuration

- **Initial database name**: `registration_db`
- **Enable backup**: Yes
- **Backup retention period**: 7 days

### Step 5: Create Database

Click **Create Database** and wait for the instance to be available (5-10 minutes).

## Configure Security Groups

### Allow Inbound Traffic

1. Go to **RDS → Databases** and select your DB instance
2. In **Connectivity & security** tab, click the security group
3. Click **Edit inbound rules**
4. Add rule:
   - **Type**: MySQL/Aurora
   - **Protocol**: TCP
   - **Port range**: 3306
   - **Source**: 
     - For local testing: `0.0.0.0/0` (allows all - only for testing)
     - For Docker: EC2 security group or specific IP
     - For production: Restricted IP range

## Create Database and Tables

### Option 1: Using MySQL CLI

```bash
# Connect to RDS instance
mysql -h your-rds-endpoint.us-east-1.rds.amazonaws.com \
      -u admin \
      -p \
      -e "source backend/database.sql"
```

### Option 2: Using MySQL Workbench

1. Open MySQL Workbench
2. Create new connection:
   - **Connection Name**: AWS Registration DB
   - **Hostname**: your-rds-endpoint
   - **Port**: 3306
   - **Username**: admin
   - **Password**: (your password)
3. Test connection
4. Open [backend/database.sql](backend/database.sql) and execute

### Option 3: Using AWS Lambda

AWS Lambda scripts can execute SQL automatically.

## Configure Application

### Step 1: Update .env File

```bash
cd /home/fl-lpt-436/ecs-task
# Edit .env file with your AWS RDS details
```

Replace the following in `.env`:

```env
MYSQL_HOST=your-rds-endpoint.us-east-1.rds.amazonaws.com
MYSQL_USER=admin
MYSQL_PASSWORD=your_secure_password_from_rds
MYSQL_DB=registration_db
MYSQL_PORT=3306
```

### Step 2: Get RDS Endpoint

1. Go to AWS RDS Console
2. Click your DB instance
3. In **Connectivity & security**, copy the **Endpoint** value
4. Use this as `MYSQL_HOST`

## Run with Docker

### Step 1: Ensure .env is Configured

```bash
cat .env
# Verify all AWS RDS details are correct
```

### Step 2: Build and Run Services

```bash
cd /home/fl-lpt-436/ecs-task

# Stop any existing containers
docker-compose down

# Build images
docker-compose build

# Start services
docker-compose up -d
```

### Step 3: Verify Services

```bash
# Check running containers
docker-compose ps

# View backend logs
docker-compose logs -f backend

# View frontend logs
docker-compose logs -f frontend
```

### Step 4: Access Application

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000

## Testing Connection

### Test from Backend Container

```bash
# Connect to backend container
docker exec -it registration_backend bash

# Test MySQL connection
python -c "
import MySQLdb
try:
    conn = MySQLdb.connect(
        host='$MYSQL_HOST',
        user='$MYSQL_USER',
        passwd='$MYSQL_PASSWORD',
        db='$MYSQL_DB'
    )
    print('✅ Successfully connected to AWS RDS MySQL')
    conn.close()
except Exception as e:
    print(f'❌ Connection failed: {e}')
"
```

### Test API Endpoints

```bash
# Test backend is running
curl http://localhost:5000/

# Register a new user
curl -X POST http://localhost:5000/api/register \
  -H "Content-Type: application/json" \
  -d '{
    "first_name": "Test",
    "last_name": "User",
    "email": "test@example.com",
    "phone": "1234567890",
    "password": "password123"
  }'

# Get all users
curl http://localhost:5000/api/users
```

## Troubleshooting

### Connection Refused

```
Error: (2003, "Can't connect to MySQL server on 'your-endpoint'")
```

**Solutions:**
- Verify RDS endpoint in `.env`
- Check security group allows port 3306
- Verify RDS instance is available
- Check MYSQL_USER and MYSQL_PASSWORD are correct

### Access Denied

```
Error: (1045, "Access denied for user 'admin'@'...'")
```

**Solutions:**
- Verify username is correct
- Verify password is correct
- Check user has appropriate privileges
- Create new user if needed:

```sql
CREATE USER 'registration_user'@'%' IDENTIFIED BY 'secure_password';
GRANT ALL PRIVILEGES ON registration_db.* TO 'registration_user'@'%';
FLUSH PRIVILEGES;
```

### Database Does Not Exist

```
Error: (1049, "Unknown database 'registration_db'")
```

**Solutions:**
- Create database manually:

```sql
CREATE DATABASE registration_db;
USE registration_db;
source backend/database.sql;
```

### Network Timeout

```
Error: Lost connection to MySQL server
```

**Solutions:**
- Check RDS instance is running (AWS Console)
- Verify security group rules
- Check firewall/VPN settings
- Increase connection timeout in code

### Docker Container Can't Reach RDS

**Solutions:**
- Ensure .env file has correct MYSQL_HOST
- Verify RDS endpoint (not just DB identifier)
- Example correct endpoint:
  ```
  mydb.c9akciq32.us-east-1.rds.amazonaws.com
  ```
- Not:
  ```
  mydb  # ❌ Wrong
  mydb.c9akciq32.us-east-1.rds.amazonaws.com:3306  # ❌ Wrong (port in env)
  ```

## Useful Commands

### View RDS Instance Details

```bash
# Using AWS CLI
aws rds describe-db-instances --db-instance-identifier registration-db

# Get endpoint
aws rds describe-db-instances \
  --db-instance-identifier registration-db \
  --query 'DBInstances[0].Endpoint.Address' \
  --output text
```

### Check RDS Connectivity

```bash
# Test from local machine (requires mysql-client)
mysql -h your-endpoint.rds.amazonaws.com -u admin -p registration_db
```

### View Docker Logs

```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f frontend
```

### Stop Services

```bash
docker-compose stop
```

### Remove All Services

```bash
docker-compose down
```

## Production Considerations

### Security

1. **Don't expose 0.0.0.0/0** in security groups (restrict to needed IPs)
2. **Use strong passwords** (minimum 16 characters)
3. **Enable RDS encryption** (at-rest and in-transit)
4. **Use SSL/TLS** for connections
5. **Enable backup and automatic patching**
6. **Use IAM database authentication** instead of passwords
7. **Store .env in secrets manager** (not in repo)

### Performance

1. **Enable Multi-AZ** for production
2. **Use appropriate instance class** (db.t3.small or larger)
3. **Enable Performance Insights** for monitoring
4. **Set up CloudWatch alarms** for disk space, CPU, connections
5. **Use Read Replicas** if needed

### Backup & Recovery

1. **Automated backups enabled** (7-35 days retention)
2. **Manual snapshots** for major changes
3. **Test restore process** regularly
4. **Document recovery procedures**

## Cost Optimization

1. **Use Free Tier** if eligible (1 year, t3.micro, 20GB storage)
2. **Monitor usage** via CloudWatch
3. **Right-size instance** based on actual load
4. **Use Reserved Instances** for stable workloads
5. **Delete unused snapshots**

## Next Steps

1. ✅ Create AWS RDS MySQL instance
2. ✅ Configure security groups
3. ✅ Create database and tables
4. ✅ Update .env file
5. ✅ Run `docker-compose up -d`
6. ✅ Access frontend at http://localhost:3000
7. ✅ Test registration and user list features

## Additional Resources

- [AWS RDS Documentation](https://docs.aws.amazon.com/rds/)
- [RDS Best Practices](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_BestPractices.html)
- [MySQL Security](https://dev.mysql.com/doc/refman/8.0/en/security.html)
- [Docker Compose Reference](https://docs.docker.com/compose/compose-file/)

---

**Happy database deploying!** 🎉
