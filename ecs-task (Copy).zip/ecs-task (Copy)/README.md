# Registration Application

A full-stack registration application built with **React.js** (Frontend), **Python Flask** (Backend), and **MySQL** (Database). Can be run locally or using **Docker** for containerized deployment.

## 📋 Features

- User registration form with validation
- **View all registered users in a table**
- Responsive and modern UI
- Secure password handling
- Email validation
- Duplicate email prevention
- RESTful API endpoints
- CORS enabled for cross-origin requests
- Environment variable configuration
- Database persistence with MySQL
- Docker support for easy deployment
- Docker Compose for orchestration

## 🏗️ Project Structure

```
registration-app/
├── frontend/                 # React Application
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/
│   │   │   ├── RegistrationForm.js
│   │   │   └── RegistrationForm.css
│   │   ├── App.js
│   │   ├── App.css
│   │   └── index.js
│   ├── Dockerfile            # Frontend Docker image
│   ├── .dockerignore         # Docker build ignore rules
│   ├── package.json
│   └── .env.example
├── backend/                  # Python Flask Application
│   ├── Dockerfile            # Backend Docker image
│   ├── .dockerignore         # Docker build ignore rules
│   ├── app.py
│   ├── requirements.txt
│   ├── database.sql
│   └── .env.example
├── docker-compose.yml        # Docker Compose orchestration
├── .env.example              # Environment template for Docker
├── README.md
└── .gitignore
```

## 🚀 Getting Started

### Prerequisites

- **Node.js** (v14.0.0 or higher)
- **npm** (v6.0.0 or higher)
- **Python** (v3.8 or higher)
- **MySQL** (v5.7 or higher)

---

## 🐳 Quick Setup with Docker (Recommended)

### Prerequisites for Docker
- **Docker** (v20.0.0 or higher)
- **Docker Compose** (v1.29.0 or higher)

### Step 1: Clone/Download the project
```bash
cd /path/to/ecs-task
```

### Step 2: Create environment file
```bash
cp .env.example .env
```

Edit `.env` file with your desired MySQL credentials:
```env
MYSQL_HOST=mysql
MYSQL_USER=registration_user
MYSQL_PASSWORD=user_password
MYSQL_ROOT_PASSWORD=root_password
MYSQL_DB=registration_db
MYSQL_PORT=3306
FLASK_ENV=development
FLASK_DEBUG=False
REACT_APP_API_URL=http://localhost:5000
```

### Step 3: Start all services with Docker Compose
```bash
docker-compose up -d
```

This command will:
- Build and start the **MySQL database** container
- Build and start the **Flask backend** container
- Build and start the **React frontend** container
- Set up networking between containers

### Step 4: Access the application
- **Frontend:** Open http://localhost:3000 in your browser
- **Backend API:** http://localhost:5000
- **MySQL:** localhost:3306

### Useful Docker Commands
```bash
# View running containers
docker-compose ps

# View logs
docker-compose logs -f

# View specific service logs
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f mysql

# Stop all services
docker-compose stop

# Start services after stopping
docker-compose start

# Rebuild containers (if code changed)
docker-compose up -d --build

# Remove all containers and volumes
docker-compose down -v

# Access backend container shell
docker exec -it registration_backend bash

# Access frontend container shell
docker exec -it registration_frontend sh

# Access MySQL container
docker exec -it registration_mysql mysql -u root -p
```

### Sample Data
When using Docker Compose, the database is automatically initialized with the `database.sql` file. You get an admin user:
```
Email: admin@example.com
Password: admin123
```

---

## 📦 Traditional Setup (Without Docker)

### 1️⃣ Database Setup

#### Step 1: Connect to MySQL

```bash
mysql -u root -p
```

#### Step 2: Create Database and Table

```bash
source backend/database.sql
```

Or manually run the SQL commands:

```sql
CREATE DATABASE IF NOT EXISTS registration_db;
USE registration_db;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_created_at (created_at)
);
```

### 2️⃣ Backend Setup

#### Step 1: Navigate to backend directory

```bash
cd backend
```

#### Step 2: Create and configure .env file

```bash
cp .env.example .env
```

Edit `.env` file with your MySQL credentials:

```env
MYSQL_HOST=localhost
MYSQL_USER=root
MYSQL_PASSWORD=your_password_here
MYSQL_DB=registration_db
MYSQL_PORT=3306
FLASK_ENV=development
FLASK_DEBUG=True
```

#### Step 3: Install dependencies

```bash
pip install -r requirements.txt
```

**Note:** If you encounter issues installing MySQLdb, try:

```bash
# For Ubuntu/Debian
sudo apt-get install python3-dev default-libmysqlclient-dev
pip install mysqlclient

# For macOS
brew install mysql
pip install mysqlclient

# Or use PyMySQL as alternative
pip install PyMySQL
```

#### Step 4: Run the backend server

```bash
python app.py
```

The backend server will run on `http://localhost:5000`

### 3️⃣ Frontend Setup

#### Step 1: Navigate to frontend directory

```bash
cd frontend
```

#### Step 2: Create and configure .env file

```bash
cp .env.example .env
```

Edit `.env` file (if needed):

```env
REACT_APP_API_URL=http://localhost:5000
REACT_APP_API_TIMEOUT=10000
```

#### Step 3: Install dependencies

```bash
npm install
```

#### Step 4: Run the frontend development server

```bash
npm start
```

The frontend will open automatically at `http://localhost:3000`

## 📡 API Endpoints

### Register User
- **Endpoint:** `POST /api/register`
- **Content-Type:** `application/json`
- **Request Body:**
```json
{
  "first_name": "John",
  "last_name": "Doe",
  "email": "john@example.com",
  "phone": "1234567890",
  "password": "password123"
}
```

- **Response (Success):**
```json
{
  "message": "Registration successful!",
  "data": {
    "first_name": "John",
    "last_name": "Doe",
    "email": "john@example.com"
  }
}
```

- **Status Code:** `201 Created`

### Get All Users
- **Endpoint:** `GET /api/users`
- **Response:**
```json
{
  "message": "Users retrieved successfully",
  "data": [
    {
      "id": 1,
      "first_name": "John",
      "last_name": "Doe",
      "email": "john@example.com",
      "phone": "1234567890",
      "created_at": "2024-01-15 10:30:00"
    }
  ],
  "count": 1
}
```

- **Status Code:** `200 OK`

### Get Single User
- **Endpoint:** `GET /api/users/<user_id>`
- **Response:**
```json
{
  "message": "User retrieved successfully",
  "data": {
    "id": 1,
    "first_name": "John",
    "last_name": "Doe",
    "email": "john@example.com",
    "phone": "1234567890",
    "created_at": "2024-01-15 10:30:00"
  }
}
```

- **Status Code:** `200 OK`

## 🗄️ MySQL Database Details

### Database: `registration_db`

### Table: `users`

| Column | Type | Constraint | Description |
|--------|------|-----------|-------------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique user identifier |
| first_name | VARCHAR(100) | NOT NULL | User's first name |
| last_name | VARCHAR(100) | NOT NULL | User's last name |
| email | VARCHAR(255) | NOT NULL, UNIQUE | User's email address |
| phone | VARCHAR(20) | NOT NULL | User's phone number |
| password | VARCHAR(255) | NOT NULL | Hashed/plain password |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Record creation timestamp |
| updated_at | TIMESTAMP | ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### Indexes
- `idx_email` on email column
- `idx_created_at` on created_at column

## 🔧 Configuration Files

### Backend .env
```env
MYSQL_HOST=localhost          # MySQL server host
MYSQL_USER=root               # MySQL username
MYSQL_PASSWORD=your_pswd      # MySQL password
MYSQL_DB=registration_db      # Database name
MYSQL_PORT=3306               # MySQL port
FLASK_ENV=development         # Flask environment
FLASK_DEBUG=True              # Enable debug mode
```

### Frontend .env
```env
REACT_APP_API_URL=http://localhost:5000  # Backend API URL
REACT_APP_API_TIMEOUT=10000              # API timeout in ms
```

## 🔒 Security Notes

- ⚠️ **Password Handling:** Currently, passwords are stored in plain text in the database. For production, implement proper password hashing using `bcrypt` or `argon2`.
- ⚠️ **CORS:** Currently allowing all origins. Restrict to specific domains in production.
- ⚠️ **Environment Variables:** Never commit `.env` files with sensitive data. Use `.env.example` as a template.
- ⚠️ **Input Validation:** Implement more robust server-side validation and sanitization.
- ⚠️ **HTTPS:** Use HTTPS in production environments.

## 📦 Dependencies

### Frontend
- react@^18.2.0
- react-dom@^18.2.0
- axios@^1.4.0
- react-scripts@5.0.1

### Backend
- Flask==2.3.2
- flask-cors==4.0.0
- flask-mysqldb==1.0.1
- python-dotenv==1.0.0
- MySQLdb==1.2.5

## 📋 Sample Test Users

After running the database setup, you can use this admin user for testing:

```
Email: admin@example.com
Password: admin123
```

## 🐛 Troubleshooting

### Backend Issues

**MySQLdb installation fails:**
```bash
# Install with pip
pip install --upgrade setuptools wheel
pip install mysqlclient

# Or use PyMySQL instead
pip install PyMySQL
```

**Cannot connect to MySQL:**
- Check if MySQL service is running
- Verify MySQL credentials in `.env`
- Ensure database/port is correct

**CORS errors:**
- Ensure frontend is accessing the correct backend URL
- Check if Flask-CORS is installed

### Frontend Issues

**Port 3000 already in use:**
```bash
# Use different port
PORT=3001 npm start
```

**API calls failing:**
- Check if backend server is running on port 5000
- Verify API URL in `.env` file
- Check browser console for error messages

## 🚀 Production Deployment

### Backend (Flask)
- Use Gunicorn/uWSGI as application server
- Deploy on Heroku, AWS EC2, or similar
- Use environment variables for sensitive data
- Implement proper logging and monitoring

### Frontend (React)
- Run `npm run build` to create optimized production build
- Deploy on Netlify, Vercel, or AWS S3 + CloudFront
- Configure environment variables for production API URL

### Database
- Use managed MySQL service (AWS RDS, Google Cloud SQL, etc.)
- Enable SSL for database connections
- Set up regular backups
- Use strong passwords

## 📝 License

MIT License - feel free to use this project

## 👨‍💻 Contributing

Feel free to fork, modify, and contribute improvements!

---

**Happy Coding!** 🎉

For more information or issues, please open a GitHub issue.
