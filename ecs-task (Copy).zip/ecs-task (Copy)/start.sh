#!/bin/bash

# Registration Application - Quick Start Script with Docker

set -e

echo "=================================="
echo "Registration Application Setup"
echo "=================================="
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

echo "✅ Docker and Docker Compose are installed"
echo ""

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "📋 Creating .env file from template..."
    cp .env.example .env
    echo "✅ .env file created. Update it with your credentials if needed."
    echo ""
fi

# Build and start containers
echo "🚀 Starting services with Docker Compose..."
docker-compose up -d

echo ""
echo "⏳ Waiting for services to be ready..."
sleep 5

# Check if services are running
echo ""
echo "Checking service status..."
docker-compose ps

echo ""
echo "=================================="
echo "✅ Services Started Successfully!"
echo "=================================="
echo ""
echo "📱 Frontend: http://localhost:3000"
echo "🔌 Backend API: http://localhost:5000"
echo "🗄️  MySQL: localhost:3306"
echo ""
echo "Test credentials:"
echo "  Email: admin@example.com"
echo "  Password: admin123"
echo ""
echo "Useful commands:"
echo "  docker-compose logs -f          # View all logs"
echo "  docker-compose logs -f frontend # View frontend logs"
echo "  docker-compose logs -f backend  # View backend logs"
echo "  docker-compose stop             # Stop services"
echo "  docker-compose down -v          # Remove services and volumes"
echo ""
