from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_mysqldb import MySQL
import re
import os
from dotenv import load_dotenv
import MySQLdb.cursors

load_dotenv()

app = Flask(__name__)
CORS(app)

# MySQL Configuration for AWS RDS
app.config['MYSQL_HOST'] = os.getenv('MYSQL_HOST', 'localhost')
app.config['MYSQL_USER'] = os.getenv('MYSQL_USER', 'root')
app.config['MYSQL_PASSWORD'] = os.getenv('MYSQL_PASSWORD', '')
app.config['MYSQL_DB'] = os.getenv('MYSQL_DB', 'registration_db')
app.config['MYSQL_PORT'] = int(os.getenv('MYSQL_PORT', 3306))
app.config['MYSQL_CHARSET'] = 'utf8mb4'
app.config['MYSQL_USE_UNICODE'] = True
# Use TCP connection instead of Unix socket by not specifying unix_socket
# This is important for AWS RDS connectivity

mysql = MySQL(app)

# Log configuration on startup
print(f"🔗 MySQL Configuration:")
print(f"  Host: {app.config['MYSQL_HOST']}")
print(f"  Port: {app.config['MYSQL_PORT']}")
print(f"  Database: {app.config['MYSQL_DB']}")
print(f"  User: {app.config['MYSQL_USER']}")

@app.route('/')
def home():
    return jsonify({'message': 'Registration API Server is Running'}), 200

@app.route('/api/register', methods=['POST'])
def register():
    cursor = None
    try:
        data = request.get_json()
        
        # Validate required fields
        if not all([data.get('first_name'), data.get('last_name'), 
                   data.get('email'), data.get('phone'), data.get('password')]):
            return jsonify({'message': 'All fields are required'}), 400
        
        first_name = data.get('first_name')
        last_name = data.get('last_name')
        email = data.get('email')
        phone = data.get('phone')
        password = data.get('password')
        
        # Validate email format
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_pattern, email):
            return jsonify({'message': 'Invalid email format'}), 400
        
        # Validate password length
        if len(password) < 6:
            return jsonify({'message': 'Password must be at least 6 characters'}), 400
        
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        
        # Check if email already exists
        cursor.execute('SELECT * FROM users WHERE email = %s', (email,))
        if cursor.fetchone():
            return jsonify({'message': 'Email already registered'}), 409
        
        # Insert new user
        cursor.execute('''
            INSERT INTO users (first_name, last_name, email, phone, password) 
            VALUES (%s, %s, %s, %s, %s)
        ''', (first_name, last_name, email, phone, password))
        
        mysql.connection.commit()
        
        return jsonify({
            'message': 'Registration successful!',
            'data': {
                'first_name': first_name,
                'last_name': last_name,
                'email': email
            }
        }), 201
        
    except Exception as e:
        return jsonify({'message': f'Error: {str(e)}'}), 500
    finally:
        if cursor:
            cursor.close()

@app.route('/api/users', methods=['GET'])
def get_users():
    cursor = None
    try:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT id, first_name, last_name, email, phone, created_at FROM users')
        users = cursor.fetchall()
        
        return jsonify({
            'message': 'Users retrieved successfully',
            'data': users,
            'count': len(users)
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Error: {str(e)}'}), 500
    finally:
        if cursor:
            cursor.close()

@app.route('/api/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    cursor = None
    try:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT id, first_name, last_name, email, phone, created_at FROM users WHERE id = %s', (user_id,))
        user = cursor.fetchone()
        
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        return jsonify({
            'message': 'User retrieved successfully',
            'data': user
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Error: {str(e)}'}), 500
    finally:
        if cursor:
            cursor.close()

@app.errorhandler(404)
def not_found(error):
    return jsonify({'message': 'Endpoint not found'}), 404

@app.errorhandler(405)
def method_not_allowed(error):
    return jsonify({'message': 'Method not allowed'}), 405

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
