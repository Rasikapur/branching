-- Create Database
CREATE DATABASE IF NOT EXISTS registration_db;

-- Use the database
USE registration_db;

-- Create Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_created_at (created_at)
);

-- Create admin user (optional)
INSERT INTO users (first_name, last_name, email, phone, password) 
VALUES ('Admin', 'User', 'admin@example.com', '9999999999', 'admin123');

-- Display table structure
DESCRIBE users;

-- Display all data
SELECT * FROM users;
